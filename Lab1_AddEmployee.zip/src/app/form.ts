export class Form {
    constructor(
        public ID:number,
        public Name:string,
        public Salary:number,
        public Department:string,
    ){}
}
